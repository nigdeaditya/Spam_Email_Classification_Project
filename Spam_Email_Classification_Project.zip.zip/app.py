
import re
import string
import pickle
import streamlit as st

st.set_page_config(page_title="Spam Email Classifier", page_icon="📧")

@st.cache_resource
def load_artifacts():
    with open("spam_model.pkl", "rb") as f:
        model = pickle.load(f)
    with open("vectorizer.pkl", "rb") as f:
        vectorizer = pickle.load(f)
    return model, vectorizer

def clean_text(text):
    text = text.lower()
    text = re.sub(r"http\S+|www\S+", " ", text)
    text = re.sub(r"\S+@\S+", " ", text)
    text = re.sub(r"\d+", " ", text)
    text = text.translate(str.maketrans("", "", string.punctuation))
    text = re.sub(r"\s+", " ", text).strip()
    return text

model, vectorizer = load_artifacts()

st.title("📧 Spam Email Classification System")
st.caption("Group D Major Project — Dataset: Preprocessing · Model: Linear SVM · UI: Streamlit")

user_input = st.text_area("Paste an email / message to classify:", height=200)

if st.button("Classify", type="primary"):
    if not user_input.strip():
        st.warning("Please enter some text first.")
    else:
        cleaned = clean_text(user_input)
        vec = vectorizer.transform([cleaned])
        pred = model.predict(vec)[0]
        if pred == 1:
            st.error("🚨 This looks like SPAM.")
        else:
            st.success("✅ This looks like a legitimate email (HAM).")
